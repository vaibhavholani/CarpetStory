//
//  MainTabBarController.swift
//  CarpetStory
//
//  Created by Aashrit Garg on 27/07/2018.
//  Copyright © 2018 Aashrit Garg. All rights reserved.
//

import UIKit
class MainTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
